16/06/2009
Ce fichier archive contient un pack de traduction en fran�ais des commandes et messages
ainsi que du fichier de configuration s'affichant sous dosbox 0.73.
Ce pack n'est pas compatible avec les versions pr�c�dentes de dosbox, consulter le site pour
t�l�charger la version appropri�e.


Proc�dure d'installation facile pour Windows :


1a. Pour Windows Vista
Copier le fichier "francais.lng" et "dosbox-073.conf" contenus dans l'archive vers le r�pertoire de dosbox 0.73 pour votre profil
"C:\Users\[votre nom]\AppData\Local\DOSBox" par d�faut
ATTENTION, faites une copie de suavegarde du fichier "dosbox-073.conf" d�j� pr�sent par s�curit�.

1b. Pour Windows XP
Copier le fichier "francais.lng" et "dosbox-073.conf" contenus dans l'archive vers le r�pertoire de dosbox 0.73 pour votre profil
"C:\Documents and Settings\[votre nom]\Local Settings\Application Data\DOSBox" par d�faut
ATTENTION, faites une copie de suavegarde du fichier "dosbox-073.conf" d�j� pr�sent par s�curit�.

-------------

2. Le fichier de configuration est d�j� modifi� pour prendre en compte le fichier de traduction.
Ouvrir avec un �diteur de texte ou notepad le fichier "dosbox-073.conf" ou cliquer sur 
le raccourci "Edit configuration" dans la section "Configuration" du groupe de programmes "DOSBox-0.73"


3. Lancer Dosbox. Il s'affiche maintenant en fran�ais!  :)

6. A l'invite de commande si le clavier n'est pas automatiquement configur� pour utiliser un clavier fran�ais, taper:
keyb fr


nota:
- Il est possible que la traduction ne concerne pas tous les messages d'information utilisables du programme.
- N'ont �t� traduits que les messages et les commandes disponibles en lan�ant 
"CONFIG -writelang nom_de_fichier" sous DOSbox.
- Il subsite dans cette version un probl�me avec l'�criture du fichier de configuration � partir d'un fichier de langue en lan�ant
"CONFIG -writeconf nom_de_fichier" sous DOSbox.
Le fichier cr�� se trouve dans le r�pertoire d'installation de DOSbox ("C:\Program Files\DOSBox-0.73" par d�faut).
Le fichier contient des sauts de ligne entre chaque commentaire traduit et certains termes ne sont pas traduits.
L'�quipe de d�veloppement est au courant et r�soudra peut-�tre cette erreur dans une future version.
-Si vous trouvez des fautes de frappe ou d'orthographe, n'h�sitez pas les signaler � l'�quipe de d�veloppement qui transmettra
ou bien directement sur le forum http://www.abandonware-forums.org � mon intention.


Bons jeux !!!
Victor